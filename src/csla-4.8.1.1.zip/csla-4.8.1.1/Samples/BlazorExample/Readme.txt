1. As can can see in the global.json file, this project uses .NET Core 2.1.300 or newer.
2. To use .NET Core 2.1 with Visual Studio, you'll need Visual Studio 2017 15.7 or newer.
3. Download .NET Core 2.1 SDK at https://www.microsoft.com/net/download/windows
