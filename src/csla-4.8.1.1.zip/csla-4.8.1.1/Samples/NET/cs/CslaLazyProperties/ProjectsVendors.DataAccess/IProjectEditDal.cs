namespace ProjectsVendors.DataAccess
{
    public partial interface IProjectEditDal
    {
    }
}
