namespace ProjectsVendors.DataAccess
{
    public partial class ProjectInfoDto
    {
    }
}
