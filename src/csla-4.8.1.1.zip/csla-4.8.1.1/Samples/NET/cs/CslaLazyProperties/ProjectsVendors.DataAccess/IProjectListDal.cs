namespace ProjectsVendors.DataAccess
{
    public partial interface IProjectListDal
    {
    }
}
