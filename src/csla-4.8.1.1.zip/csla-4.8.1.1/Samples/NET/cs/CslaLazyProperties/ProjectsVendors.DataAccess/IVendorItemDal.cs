namespace ProjectsVendors.DataAccess
{
    public partial interface IVendorItemDal
    {
    }
}
