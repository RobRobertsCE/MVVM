namespace ProjectsVendors.DataAccess
{
    public partial class VendorItemDto
    {
    }
}
