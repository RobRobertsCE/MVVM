namespace ProjectsVendors.DataAccess
{
    public partial interface IVendorCollectionDal
    {
    }
}
