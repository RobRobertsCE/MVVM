namespace ProjectsVendors.DataAccess
{
    public partial class ProjectEditDto
    {
    }
}
