using System;
using Csla;
using ProjectsVendors.DataAccess;

namespace ProjectsVendors.DataAccess.Sql
{
    public partial class ProjectEditDal
    {
    }
}
