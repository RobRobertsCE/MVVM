using System;
using System.Collections.Generic;
using System.Text;
using Csla;

namespace BLBTest
{
  [Serializable]
  public class DataList : BusinessBindingListBase<DataList, DataEdit>
  {

  }
}
