﻿namespace Rolodex.Silverlight.Views
{
  public interface IFocusable
  {
    bool Focus();
  }
}