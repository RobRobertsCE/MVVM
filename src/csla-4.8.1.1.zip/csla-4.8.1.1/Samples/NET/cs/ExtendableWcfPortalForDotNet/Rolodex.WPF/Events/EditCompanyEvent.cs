﻿using Microsoft.Practices.Composite.Presentation.Events;

namespace Rolodex.Silverlight.Events
{
  public class EditCompanyEvent : CompositePresentationEvent<EditCompanyEventArgs>
  {
  }
}