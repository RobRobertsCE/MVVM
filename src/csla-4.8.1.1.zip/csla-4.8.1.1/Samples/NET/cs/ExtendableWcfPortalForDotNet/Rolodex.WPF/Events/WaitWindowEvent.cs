﻿using Microsoft.Practices.Composite.Presentation.Events;

namespace Rolodex.Silverlight.Events
{
  public class WaitWindowEvent : CompositePresentationEvent<bool>
  {
  }
}