﻿using System;
using Microsoft.Practices.Composite.Presentation.Events;

namespace Rolodex.Silverlight.Events
{
  public class ShowCompaniesListEvent : CompositePresentationEvent<EventArgs>
  {
  }
}