//-----------------------------------------------------------------------
// <copyright file="OrderDetailDal.cs" company="Marimer LLC">
//     Copyright (c) Marimer LLC. All rights reserved.
//     Website: http://www.lhotka.net/cslanet/
// </copyright>
// <summary></summary>
// <remarks>Generated file.</remarks>
//-----------------------------------------------------------------------

using System;
using Csla;

namespace ActionExtenderSample.DataAccess.Sql
{
  public partial class OrderDetailDal
  {
  }
}
