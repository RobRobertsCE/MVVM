//-----------------------------------------------------------------------
// <copyright file="OrderDetailCollection.cs" company="Marimer LLC">
//     Copyright (c) Marimer LLC. All rights reserved.
//     Website: http://www.lhotka.net/cslanet/
// </copyright>
// <summary></summary>
// <remarks>Generated file.</remarks>
//-----------------------------------------------------------------------

using System;
using Csla;

namespace ActionExtenderSample.Business
{
  public partial class OrderDetailCollection
  {

    #region OnDeserialized actions

    /*/// <summary>
    /// This method is called on a newly deserialized object
    /// after deserialization is complete.
    /// </summary>
    protected override void OnDeserialized()
    {
        base.OnDeserialized();
        // add your custom OnDeserialized actions here.
    }*/

    #endregion

    #region Implementation of DataPortal Hooks

    //partial void OnFetchPre(DataPortalHookArgs args)
    //{
    //    throw new NotImplementedException();
    //}

    //partial void OnFetchPost(DataPortalHookArgs args)
    //{
    //    throw new NotImplementedException();
    //}

    #endregion

  }
}
