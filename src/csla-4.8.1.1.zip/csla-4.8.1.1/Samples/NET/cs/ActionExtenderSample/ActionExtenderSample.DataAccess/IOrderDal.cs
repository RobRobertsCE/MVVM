//-----------------------------------------------------------------------
// <copyright file="IOrderDal.cs" company="Marimer LLC">
//     Copyright (c) Marimer LLC. All rights reserved.
//     Website: http://www.lhotka.net/cslanet/
// </copyright>
// <summary></summary>
// <remarks>Generated file.</remarks>
//-----------------------------------------------------------------------

namespace ActionExtenderSample.DataAccess
{
  public partial interface IOrderDal
  {
  }
}
