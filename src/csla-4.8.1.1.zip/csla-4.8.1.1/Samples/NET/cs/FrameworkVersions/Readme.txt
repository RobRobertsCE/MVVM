FrameworkVersions.Net46 falls back to net45
CSPROJ file should say
<HintPath>..\..\..\..\..\packages\CSLA-Core.4.8.1\lib\net45\Csla.dll</HintPath>

FrameworkVersions.Net461 uses net461
CSPROJ file should say
<HintPath>..\..\..\..\..\packages\CSLA-Core.4.8.1\lib\net461\Csla.dll</HintPath>
