﻿namespace FrameworkVersions
{
    public class Class1
    {
    }
}
