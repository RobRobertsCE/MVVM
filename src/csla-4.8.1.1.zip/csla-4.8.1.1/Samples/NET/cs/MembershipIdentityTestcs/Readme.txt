This samples doesn't use a connection string and defaults to the 
SQL Server instance .\SQLEXPRESS