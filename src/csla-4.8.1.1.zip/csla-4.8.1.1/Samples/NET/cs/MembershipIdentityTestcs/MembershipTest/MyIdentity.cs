﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Csla.Security;

namespace MembershipTest
{
  [Serializable]
  public class MyIdentity : MembershipIdentity
  {  }
}
